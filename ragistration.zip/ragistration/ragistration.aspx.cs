﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace home
{
    public partial class ragistration : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Student\source\repos\home\home\App_Data\DB.mdf;Integrated Security=True");
        string g;
        protected void Page_Load(object sender, EventArgs e)
        {
            display();
        }
        public void display()
        {
            string q = "Select * from ragistration ";
            SqlDataAdapter adp = new SqlDataAdapter(q, con);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void login_Click(object sender, EventArgs e)
        {
            if(male.Checked==true)
            {
                g = "male";
            }
            else
            {
                g = "female";
            }
            con.Open();
            string q = "insert into ragistration(empname,designation,gender,mobile) values('" + empbox.Text + "','" + DropDownList1.SelectedValue + "','" + g + "'," + mobileBox.Text + ")";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.ExecuteNonQuery();
            display();
            Response.Write("data add");
                con.Close();
        }
    }
}