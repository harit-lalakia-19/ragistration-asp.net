﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ragistration.aspx.cs" Inherits="home.ragistration" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            
            <asp:Label ID="empname" runat="server" Text="empname"></asp:Label>
            <asp:TextBox ID="empbox" runat="server" style="margin-left: 113px" Width="221px" Height="23px"></asp:TextBox><br />
            <asp:Label ID="designation" runat="server" Text="designation"></asp:Label>
            <asp:DropDownList ID="DropDownList1" runat="server" Height="23px" style="margin-left: 101px" Width="229px">
                <asp:ListItem>HR</asp:ListItem>
                <asp:ListItem>PROFESSOR</asp:ListItem>
                <asp:ListItem>CLARK</asp:ListItem>
                <asp:ListItem>SUPERVISOR</asp:ListItem>
            </asp:DropDownList><br />
            <asp:Label ID="gender" runat="server" Text="gender"></asp:Label>
            <asp:RadioButton ID="male" runat="server" GroupName="1" Text="male" BorderStyle="Ridge" />
            <asp:RadioButton ID="female" runat="server" GroupName="1" Text="female" BorderStyle="Ridge"/><br />
            <asp:Label ID="mobile" runat="server" Text="mobile"></asp:Label>
            <asp:TextBox ID="mobileBox" runat="server" Height="23px" style="margin-left: 130px" Width="221px"></asp:TextBox><br /><br />
            <asp:Button ID="login" runat="server" Text="Button" style="margin-left: 123px" OnClick="login_Click" /><br /><br />

           


            <asp:GridView ID="GridView1" runat="server"></asp:GridView>
        </div>

    </form>
</body>
</html>
